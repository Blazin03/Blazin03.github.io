# Credits

## stylelint-icon

[Tuxedo](https://thenounproject.com/term/tuxedo/2104/) by [Kenneth Von Alt](https://thenounproject.com/KenVonAlt).

## stylelint-text

[Niconne](https://fonts.google.com/specimen/Niconne) by [Vernon Adams](http://sansoxygen.com/).
