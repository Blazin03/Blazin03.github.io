declare var testRule: import('jest-preset-stylelint').TestRule;
