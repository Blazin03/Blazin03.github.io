declare module 'supports-hyperlinks' {
	var supportsHyperlinks: {
		stdout: boolean;
		stderr: boolean;
	};

	export = supportsHyperlinks;
}
