declare module 'normalize-selector' {
	function normalizeSelector(selector: string): string;

	export = normalizeSelector;
}
